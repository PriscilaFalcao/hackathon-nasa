import pandas as pd

def mostrar():
    try:
        with open('/content/test_curl.txt', 'r') as fr:
            # reading line by line
            lines = fr.readlines()
            
            # pointer for position
            ptr = 1
        
            # opening in writing mode
            with open('test_curl.txt', 'w') as fw:
                for line in lines:
                    
                    # we want to remove 5th line
                    if ptr != 0 or ptr != 1 or ptr!= 2 or ptr != 3 or ptr!= 4 or ptr!= 5:
                        fw.write(line)
                    ptr += 1
        file = lines[9:21202]
        print(file)
    except:
        print("Oops! someting error")

    dataframe = file

    import re
    dataframe = '/'.join(dataframe)
    dataframe = re.sub(r"\s+", " ", dataframe)
    dataframe

    dataset = dataframe.split(' ')

    dataset = pd.DataFrame(pd.Series(dataframe).str.split('/').tolist())
    dataset = dataset.T

    dataset = dataset[0].str.split(' ', expand=True)

    del dataset[6]

    for i in range(len(dataset.columns)):
        dataset[dataset[i][0]] = dataset[i]
        del dataset[i]
        dataset = dataset.drop(labels=0, axis=0)
        dataset = dataset.apply(pd.to_numeric)
        dataset = dataset.reset_index()
        del dataset['index']

    import seaborn as sns
    sns.set_theme(style="white")


    x = np.array(dataset['2'])
    y = np.array(dataset['3'])
    z = np.array(dataset['1'])
    data = pd.DataFrame.from_dict(np.array([x,y,z]).T)

    g = sns.PairGrid(data, diag_sharey=False)
    g.map_upper(sns.scatterplot, s=15)
    g.map_lower(sns.kdeplot)
    g.map_diag(sns.kdeplot, lw=2)